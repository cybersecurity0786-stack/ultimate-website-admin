let csrf = '';
let sites = [];
let currentView = 'overview';
const $ = id => document.getElementById(id);
async function api(url, options={}) {
  const headers = { ...(options.body ? {'Content-Type':'application/json'} : {}), ...(options.headers||{}) };
  if (options.method && options.method !== 'GET' && csrf) headers['x-csrf-token'] = csrf;
  const response = await fetch(url, {...options, headers, credentials:'same-origin'});
  const data = response.status === 204 ? null : await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data?.error || `Request failed (${response.status})`);
  return data;
}
function toast(message){const el=$('toast');el.textContent=message;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2600)}
function fmt(n){return Number(n||0).toLocaleString()}
async function refreshCsrf(){const d=await api('/api/csrf');csrf=d.csrf}
function showView(name){
  currentView=name;
  document.querySelectorAll('.view').forEach(v=>v.classList.toggle('hidden',v.id!==name));
  document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('active',b.dataset.view===name));
  const labels={overview:'Overview',websites:'My Websites',editor:'Code Manager',pages:'Page Manager',guide:'Connect & Publish'};
  $('viewTitle').textContent=labels[name];$('crumb').textContent=labels[name].toUpperCase();
  if(name==='websites'||name==='overview') loadSites();
  if(name==='editor') fillEditorSites();
  if(name==='pages') fillPageSites();
}
function siteCard(s){
  return `<article class="site-card"><h4>${esc(s.name)}</h4><div class="site-url">${esc(s.url)}</div><div class="site-metrics"><div><b>${fmt(s.total_visits)}</b><small>TOTAL VIEWS</small></div><div><b>${fmt(s.today_visits)}</b><small>TODAY</small></div><div><b>${fmt(s.live_visitors)}</b><small>LIVE*</small></div></div><div class="site-actions"><button class="secondary" data-copy="${escAttr(`<script src="${location.origin}/track.js" data-site-id="${s.id}"></script>`)}">Copy tracking code</button><button class="secondary" data-edit="${s.id}">Open editor</button><button class="danger" data-delete="${s.id}">Remove</button></div></article>`;
}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function escAttr(s){return esc(s).replace(/`/g,'&#96;')}
async function loadSites(){
  try{
    sites=await api('/api/sites');
    $('totalSites').textContent=fmt(sites.length);
    $('totalViews').textContent=fmt(sites.reduce((a,s)=>a+Number(s.total_visits||0),0));
    $('todayViews').textContent=fmt(sites.reduce((a,s)=>a+Number(s.today_visits||0),0));
    $('liveViews').textContent=fmt(sites.reduce((a,s)=>a+Number(s.live_visitors||0),0));
    $('overviewSites').innerHTML=sites.length?sites.map(siteCard).join(''):'<p class="muted">No websites yet. Choose “Add website” to get started.</p>';
    $('siteList').innerHTML=sites.length?sites.map(siteCard).join(''):'<p class="muted">No websites registered yet.</p>';
    bindSiteActions();
  }catch(e){toast(e.message)}
}
function bindSiteActions(){
  document.querySelectorAll('[data-copy]').forEach(b=>b.onclick=async()=>{await navigator.clipboard.writeText(b.dataset.copy);toast('Tracking code copied')});
  document.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>{showView('editor');$('editorSite').value=b.dataset.edit;loadFiles()});
  document.querySelectorAll('[data-delete]').forEach(b=>b.onclick=async()=>{if(!confirm('Remove this website and its stored analytics/workspace?'))return;try{await api('/api/sites/'+b.dataset.delete,{method:'DELETE'});toast('Website removed');loadSites()}catch(e){toast(e.message)}});
}
async function fillEditorSites(){
  $('editorSite').innerHTML='<option value="">Select a website</option>'+sites.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join('');
}
async function fillPageSites(){
  $('pageSite').innerHTML='<option value="">Choose website</option>'+sites.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join('');
  await loadPages();
}
async function loadFiles(){
  const id=$('editorSite').value;if(!id)return;
  try{const files=await api(`/api/sites/${id}/files`);$('fileSelect').innerHTML=files.map(f=>`<option value="${escAttr(f)}">${esc(f)}</option>`).join('');await loadFile()}catch(e){toast(e.message)}
}
async function loadFile(){
  const id=$('editorSite').value;if(!id)return toast('Select a website first');
  try{const d=await api(`/api/sites/${id}/file?path=${encodeURIComponent($('fileSelect').value)}`);$('codeEditor').value=d.content;$('editorMessage').textContent='File loaded. Save creates a backup of the previous version.'}catch(e){$('codeEditor').value='';toast(e.message)}
}
async function loadPages(){
  const id=$('pageSite').value;if(!id){$('pageList').innerHTML='';return}
  try{const pages=await api('/api/pages/'+id);$('pageList').innerHTML=pages.map(p=>`<div class="page-item"><div><b>${esc(p.title)}</b><br><small>/${esc(p.slug)} · ${p.published?'Published':'Draft'}</small></div><button class="danger" data-page-delete="${p.id}">Delete</button></div>`).join('')||'<p class="muted">No pages created for this website.</p>';document.querySelectorAll('[data-page-delete]').forEach(b=>b.onclick=async()=>{try{await api('/api/pages/'+b.dataset.pageDelete,{method:'DELETE'});loadPages();toast('Page deleted')}catch(e){toast(e.message)}})}catch(e){toast(e.message)}
}
$('loginForm').onsubmit=async e=>{e.preventDefault();$('loginError').textContent='';try{const d=await api('/api/login',{method:'POST',body:JSON.stringify({username:$('username').value,password:$('password').value})});csrf=d.csrf;enterApp()}catch(err){$('loginError').textContent=err.message}};
async function enterApp(){$('login').classList.add('hidden');$('app').classList.remove('hidden');await refreshCsrf();showView('overview');}
$('logout').onclick=async()=>{try{await api('/api/logout',{method:'POST'});location.reload()}catch(e){toast(e.message)}};
document.querySelectorAll('.nav').forEach(b=>b.onclick=()=>showView(b.dataset.view));
document.querySelectorAll('[data-goto]').forEach(b=>b.onclick=()=>showView(b.dataset.goto));
$('addSiteForm').onsubmit=async e=>{e.preventDefault();try{await api('/api/sites',{method:'POST',body:JSON.stringify({name:$('siteName').value,url:$('siteUrl').value})});$('addSiteForm').reset();toast('Website added');await loadSites()}catch(err){toast(err.message)}};
$('editorSite').onchange=loadFiles;$('loadFile').onclick=loadFile;
$('saveFile').onclick=async()=>{const id=$('editorSite').value;if(!id)return toast('Select a website first');try{const d=await api(`/api/sites/${id}/file`,{method:'PUT',body:JSON.stringify({path:$('fileSelect').value,content:$('codeEditor').value})});toast('Code saved with backup');$('editorMessage').textContent=d.message}catch(e){toast(e.message)}};
$('pageSite').onchange=loadPages;
$('pageForm').onsubmit=async e=>{e.preventDefault();try{await api('/api/pages',{method:'POST',body:JSON.stringify({site_id:$('pageSite').value,title:$('pageTitle').value,slug:$('pageSlug').value,body:$('pageBody').value,published:$('pagePublished').checked})});$('pageTitle').value='';$('pageSlug').value='';$('pageBody').value='';$('pagePublished').checked=false;toast('Page record saved');loadPages()}catch(e){toast(e.message)}};
(async()=>{try{const me=await api('/api/me');if(me.authenticated){await refreshCsrf();enterApp()}}catch(e){console.error(e)}})();
