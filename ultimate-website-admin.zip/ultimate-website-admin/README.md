# Ultimate Website Control Center

A full-stack starter admin panel with:
- Secure admin login configured through environment variables
- Multiple website registry
- Visitor tracking endpoint and analytics totals
- Page/content records
- HTML/CSS/JS source workspace with automatic per-file backups
- Responsive dark neon dashboard

## Important: what this project does and does not do

Adding a URL does **not** automatically grant control over that remote website. You must own the site or have permission to administer it.

The code editor edits files in this app's own server-side workspace (`data/sites/<site-id>/`). It does not silently overwrite files on another host. To publish edits to a real website, connect that website's Git repository or hosting deployment pipeline and review changes before deploying.

The visitor tracker counts visits only after you install the provided tracking snippet on the pages you want to measure. It stores a daily hashed visitor identifier rather than raw IP addresses. It is an approximate analytics counter, not a complete analytics platform.

This is a Node.js backend application. **GitHub Pages alone cannot run it**, because GitHub Pages serves static files and does not run Node.js or SQLite. Use GitHub to store the source code, then deploy the app to a Node.js host with persistent storage (for example, Render with a persistent disk).

## Run locally

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Set a strong unique `SESSION_SECRET`, `ADMIN_USERNAME`, and `ADMIN_PASSWORD`.
4. Run:

   ```bash
   npm install
   npm start
   ```

5. Open `http://localhost:3000`.

Do not commit `.env` or the `data/` directory.

## GitHub

1. Create a new private repository on GitHub.
2. Upload the contents of this folder (not the ZIP file itself).
3. Confirm `.env` and `data/` are excluded by `.gitignore`.
4. In your hosting provider, import the GitHub repository.
5. Configure environment variables:
   - `NODE_ENV=production`
   - `SESSION_SECRET` (long random secret)
   - `ADMIN_USERNAME`
   - `ADMIN_PASSWORD` (at least 14 characters)
   - `DATA_DIR=/var/data` when using the included Render disk config
6. Attach persistent storage at `/var/data`. Without persistent storage, SQLite data can be lost on redeploy/restart.
7. Deploy and open the generated HTTPS URL.

The included `render.yaml` is a starting point. A persistent disk may require a paid hosting plan. Review current provider pricing and configuration before deployment.

## Install visitor tracking

After adding a website in the dashboard, copy its tracking snippet and add it to the website's HTML before `</body>`:

```html
<script src="https://YOUR-ADMIN-DOMAIN/track.js" data-site-id="YOUR_SITE_ID"></script>
```

Replace the domain and site ID with the values shown by your deployment and dashboard. Install it on each page you want to track. Test by opening your website and refreshing the dashboard.

## Security checklist before production

- Use HTTPS.
- Use a unique, strong admin password and session secret.
- Keep `.env`, database files, backups and deployment tokens private.
- Restrict dashboard access to trusted administrators.
- Back up the persistent disk regularly.
- Keep dependencies updated.
- Review code changes before publishing them to a public website.
- Add a privacy notice/cookie disclosure appropriate to your visitors and jurisdiction.
- For a public multi-user product, add stronger role management, CSRF testing, audit trails, upload scanning, and a proper deployment integration before launch.

## Current limitations

- Single administrator configured by environment variables.
- Page manager stores content records; it does not automatically rewrite the registered remote website.
- Code workspace is separate from the remote website until a deployment pipeline is connected.
- No automatic ZIP deployment to arbitrary URLs. This is intentionally not implemented: a URL alone is not proof of ownership or permission.
- Analytics are basic page-view counts, with a five-minute live-visitor estimate.
