'use strict';
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve(process.env.DATA_DIR || './data');
const SITES_DIR = path.join(DATA_DIR, 'sites');
fs.mkdirSync(SITES_DIR, { recursive: true });
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  if (process.env.NODE_ENV === 'production') throw new Error('Set SESSION_SECRET to a random value of at least 32 characters.');
  console.warn('WARNING: Set a long random SESSION_SECRET before deployment.');
}
if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD) {
  throw new Error('Set ADMIN_USERNAME and ADMIN_PASSWORD in your environment.');
}
if (process.env.NODE_ENV === 'production' && process.env.ADMIN_PASSWORD.length < 14) {
  throw new Error('ADMIN_PASSWORD must be at least 14 characters in production.');
}

const db = new Database(path.join(DATA_DIR, 'admin.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sites (id TEXT PRIMARY KEY, name TEXT NOT NULL, url TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS visits (id INTEGER PRIMARY KEY AUTOINCREMENT, site_id TEXT NOT NULL, page TEXT, visitor_hash TEXT, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS visits_site_date ON visits(site_id, created_at);
CREATE TABLE IF NOT EXISTS pages (id INTEGER PRIMARY KEY AUTOINCREMENT, site_id TEXT NOT NULL, title TEXT NOT NULL, slug TEXT NOT NULL, body TEXT NOT NULL DEFAULT '', published INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL);
`);

const admin = db.prepare('SELECT id FROM admins WHERE username = ?').get(process.env.ADMIN_USERNAME);
if (!admin) {
  const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD, 12);
  db.prepare('INSERT INTO admins (username, password_hash) VALUES (?, ?)').run(process.env.ADMIN_USERNAME, hash);
}

app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: false, limit: '2mb' }));
app.use(session({
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: DATA_DIR, table: 'sessions' }),
  secret: process.env.SESSION_SECRET || 'development-only-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production', maxAge: 8 * 60 * 60 * 1000 }
}));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false });
function requireAuth(req, res, next) {
  if (!req.session.adminId) return res.status(401).json({ error: 'Please log in.' });
  next();
}
function requireCsrf(req, res, next) {
  if (!req.session.csrf || req.get('x-csrf-token') !== req.session.csrf) return res.status(403).json({ error: 'Security token expired. Refresh and try again.' });
  next();
}
function safeSiteId() { return crypto.randomBytes(12).toString('hex'); }
function safePath(siteId, file) {
  if (!/^[a-f0-9]{24}$/.test(siteId)) throw new Error('Invalid website ID.');
  if (typeof file !== 'string' || !file || file.length > 180 || file.includes('\\') || file.startsWith('/') || file.includes('..')) throw new Error('Invalid file path.');
  const allowed = /\.(html|css|js|json|txt|md|svg)$/i;
  if (!allowed.test(file)) throw new Error('Only HTML, CSS, JS, JSON, TXT, MD and SVG files are allowed.');
  const root = path.resolve(SITES_DIR, siteId);
  const target = path.resolve(root, file);
  if (!target.startsWith(root + path.sep)) throw new Error('Invalid file path.');
  return { root, target };
}
function ensureSiteFolder(id) {
  const dir = path.join(SITES_DIR, id);
  fs.mkdirSync(dir, { recursive: true });
  const index = path.join(dir, 'index.html');
  if (!fs.existsSync(index)) fs.writeFileSync(index, '<!doctype html>\\n<html><head><meta charset="utf-8"><title>My website</title><link rel="stylesheet" href="style.css"></head><body><h1>Your website workspace is ready</h1><script src="app.js"></script></body></html>\\n');
  const css = path.join(dir, 'style.css');
  const js = path.join(dir, 'app.js');
  if (!fs.existsSync(css)) fs.writeFileSync(css, 'body { font-family: Arial, sans-serif; margin: 3rem; }\\nh1 { color: #176b36; }\\n');
  if (!fs.existsSync(js)) fs.writeFileSync(js, "console.log('Website workspace loaded');\\n");
}

app.get('/api/csrf', (req, res) => {
  req.session.csrf = crypto.randomBytes(24).toString('hex');
  res.json({ csrf: req.session.csrf });
});
app.post('/api/login', loginLimiter, (req, res) => {
  const { username, password } = req.body || {};
  const row = db.prepare('SELECT id, password_hash FROM admins WHERE username = ?').get(String(username || ''));
  if (!row || !bcrypt.compareSync(String(password || ''), row.password_hash)) return res.status(401).json({ error: 'Incorrect username or password.' });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'Could not start secure session.' });
    req.session.adminId = row.id;
    req.session.csrf = crypto.randomBytes(24).toString('hex');
    res.json({ ok: true, csrf: req.session.csrf });
  });
});
app.get('/api/me', (req, res) => res.json({ authenticated: !!req.session.adminId }));
app.post('/api/logout', requireAuth, requireCsrf, (req, res) => req.session.destroy(() => res.json({ ok: true })));

app.get('/api/sites', requireAuth, (req, res) => {
  const sites = db.prepare(`SELECT s.*,
    (SELECT COUNT(*) FROM visits v WHERE v.site_id=s.id) AS total_visits,
    (SELECT COUNT(*) FROM visits v WHERE v.site_id=s.id AND date(v.created_at)=date('now')) AS today_visits,
    (SELECT COUNT(DISTINCT visitor_hash) FROM visits v WHERE v.site_id=s.id AND v.created_at >= datetime('now','-5 minutes')) AS live_visitors
    FROM sites s ORDER BY created_at DESC`).all();
  res.json(sites);
});
app.post('/api/sites', requireAuth, requireCsrf, (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 80);
  const url = String(req.body.url || '').trim();
  let parsed;
  try { parsed = new URL(url); } catch { return res.status(400).json({ error: 'Enter a valid website URL.' }); }
  if (!['http:', 'https:'].includes(parsed.protocol)) return res.status(400).json({ error: 'Only HTTP and HTTPS website URLs are allowed.' });
  if (!name) return res.status(400).json({ error: 'Website name is required.' });
  const id = safeSiteId();
  db.prepare('INSERT INTO sites (id,name,url,created_at) VALUES (?,?,?,?)').run(id, name, parsed.origin, new Date().toISOString());
  ensureSiteFolder(id);
  res.json({ id, name, url: parsed.origin });
});
app.delete('/api/sites/:id', requireAuth, requireCsrf, (req, res) => {
  const site = db.prepare('SELECT id FROM sites WHERE id=?').get(req.params.id);
  if (!site) return res.status(404).json({ error: 'Website not found.' });
  db.prepare('DELETE FROM visits WHERE site_id=?').run(site.id);
  db.prepare('DELETE FROM pages WHERE site_id=?').run(site.id);
  db.prepare('DELETE FROM sites WHERE id=?').run(site.id);
  fs.rmSync(path.join(SITES_DIR, site.id), { recursive: true, force: true });
  res.json({ ok: true });
});
app.get('/api/sites/:id/stats', requireAuth, (req, res) => {
  const site = db.prepare('SELECT id FROM sites WHERE id=?').get(req.params.id);
  if (!site) return res.status(404).json({ error: 'Website not found.' });
  const daily = db.prepare(`SELECT date(created_at) AS day, COUNT(*) AS views FROM visits WHERE site_id=? AND created_at >= datetime('now','-6 days') GROUP BY date(created_at) ORDER BY day`).all(site.id);
  const totals = db.prepare(`SELECT COUNT(*) AS total, COUNT(DISTINCT visitor_hash) AS unique_visitors,
    SUM(CASE WHEN date(created_at)=date('now') THEN 1 ELSE 0 END) AS today
    FROM visits WHERE site_id=?`).get(site.id);
  res.json({ totals, daily });
});

app.get('/api/sites/:id/files', requireAuth, (req, res) => {
  try {
    const { root } = safePath(req.params.id, 'index.html');
    if (!fs.existsSync(root)) return res.json(['index.html']);
    const walk = (dir, prefix='') => fs.readdirSync(dir, { withFileTypes: true }).flatMap(ent => {
      if (ent.isSymbolicLink()) return [];
      const rel = path.posix.join(prefix, ent.name);
      if (ent.isDirectory()) return walk(path.join(dir, ent.name), rel);
      return /\.(html|css|js|json|txt|md|svg)$/i.test(ent.name) ? [rel] : [];
    });
    res.json(walk(root));
  } catch (e) { res.status(400).json({ error: e.message }); }
});
app.get('/api/sites/:id/file', requireAuth, (req, res) => {
  try {
    const { target } = safePath(req.params.id, String(req.query.path || 'index.html'));
    if (!fs.existsSync(target)) return res.status(404).json({ error: 'File not found.' });
    res.json({ path: req.query.path, content: fs.readFileSync(target, 'utf8') });
  } catch (e) { res.status(400).json({ error: e.message }); }
});
app.put('/api/sites/:id/file', requireAuth, requireCsrf, (req, res) => {
  try {
    const { root, target } = safePath(req.params.id, String(req.body.path || ''));
    const content = String(req.body.content ?? '');
    if (content.length > 500000) return res.status(413).json({ error: 'File is too large (500 KB maximum).' });
    fs.mkdirSync(path.dirname(target), { recursive: true });
    if (fs.existsSync(target)) {
      const backupDir = path.join(root, '.backups');
      fs.mkdirSync(backupDir, { recursive: true });
      const stamp = new Date().toISOString().replace(/[:.]/g, '-');
      fs.copyFileSync(target, path.join(backupDir, path.basename(target) + '.' + stamp + '.bak'));
    }
    fs.writeFileSync(target, content, 'utf8');
    res.json({ ok: true, message: 'Saved in this server workspace. Deploy/sync the files to your live host to publish them.' });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.get('/api/pages/:siteId', requireAuth, (req, res) => {
  res.json(db.prepare('SELECT * FROM pages WHERE site_id=? ORDER BY updated_at DESC').all(req.params.siteId));
});
app.post('/api/pages', requireAuth, requireCsrf, (req, res) => {
  const siteId = String(req.body.site_id || '');
  if (!db.prepare('SELECT id FROM sites WHERE id=?').get(siteId)) return res.status(404).json({ error: 'Website not found.' });
  const title = String(req.body.title || '').trim().slice(0, 120);
  const slug = String(req.body.slug || '').trim().toLowerCase().replace(/[^a-z0-9-]/g, '-').slice(0, 100);
  if (!title || !slug) return res.status(400).json({ error: 'Title and slug are required.' });
  const info = db.prepare('INSERT INTO pages (site_id,title,slug,body,published,updated_at) VALUES (?,?,?,?,?,?)')
    .run(siteId, title, slug, String(req.body.body || '').slice(0, 100000), req.body.published ? 1 : 0, new Date().toISOString());
  res.json({ id: info.lastInsertRowid });
});
app.delete('/api/pages/:id', requireAuth, requireCsrf, (req, res) => {
  db.prepare('DELETE FROM pages WHERE id=?').run(Number(req.params.id));
  res.json({ ok: true });
});

// Public, privacy-minimised tracking endpoint. It stores a salted daily visitor hash, not raw IP addresses.
app.post('/api/track', (req, res) => {
  const siteId = String(req.body.site_id || '');
  if (!db.prepare('SELECT id FROM sites WHERE id=?').get(siteId)) return res.status(404).json({ error: 'Unknown site.' });
  const ip = req.ip || 'unknown';
  const day = new Date().toISOString().slice(0,10);
  const visitorHash = crypto.createHash('sha256').update(ip + day + siteId + (process.env.SESSION_SECRET || '')).digest('hex');
  const page = String(req.body.page || '/').slice(0, 300);
  db.prepare('INSERT INTO visits (site_id,page,visitor_hash,created_at) VALUES (?,?,?,?)')
    .run(siteId, page, visitorHash, new Date().toISOString());
  res.set('Access-Control-Allow-Origin', '*').status(204).end();
});
app.options('/api/track', (req, res) => res.set('Access-Control-Allow-Origin', '*').set('Access-Control-Allow-Methods', 'POST, OPTIONS').set('Access-Control-Allow-Headers', 'Content-Type').sendStatus(204));

app.get('/track.js', (req, res) => {
  res.type('application/javascript').send(`(()=>{const s=document.currentScript?.dataset.siteId;if(!s)return;const send=()=>fetch(${JSON.stringify('') }+'/api/track'.replace(/^\\//,location.protocol+'//'+location.host+'/'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({site_id:s,page:location.pathname}),keepalive:true}).catch(()=>{});send()})();`);
});
app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, () => console.log(`Admin panel running on port ${PORT}`));
